//
//  GameScene.swift
//  project_final
//
//  Created by Shruti Kapadia on 2021-12-06.
//

import SpriteKit
import GameplayKit
import CoreMotion

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    
    var field8640:SKEmitterNode!
    var gamer8640:SKSpriteNode!
    var scoreLabel:SKLabelNode!
    var animals = ["animal1","animal2", "animal3"]
    
    let Category:UInt32 = 0x1 << 1
    let clashStyle:UInt32 = 0x1 << 0
    
    let movement = CMMotionManager()
    var xSpeed:CGFloat = 0
    
    
    var score:Int = 0 {
        didSet {
            scoreLabel.text = "Score: \(score)"
        }
    }
    
    var Time8640:Timer!
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    @objc func Intersticial_animal () {
        animals = GKRandomSource.sharedRandom().arrayByShufflingObjects(in: animals) as! [String]
        
        let anime = SKSpriteNode(imageNamed: animals[0])
        let randomAnime = GKRandomDistribution(lowestValue: 0,highestValue: 100)
        let pos = CGFloat(randomAnime.nextInt())
        
        anime.position =  CGPoint(x: pos, y: self.frame.size.height +  anime.size.height)
        anime.physicsBody = SKPhysicsBody(rectangleOf: anime.size)
        anime.physicsBody?.isDynamic = true
        
        anime.physicsBody?.categoryBitMask = Category
        anime.physicsBody?.contactTestBitMask = clashStyle
        anime.physicsBody?.collisionBitMask = 0
        
        self.addChild(anime)
        let animation_time:TimeInterval = 3
        var task = [SKAction]()
        
        task.append(SKAction.move(to: CGPoint(x: -120, y: -350), duration: animation_time))
        task.append(SKAction.removeFromParent())
        
        anime.run(SKAction.sequence(task))
        
        
        
        
    }
    

    
    
    
    func target_animal()
    {
        self.run(SKAction.playSoundFileNamed("spaceship.mp3", waitForCompletion: false))
        let t_node = SKSpriteNode(imageNamed: "fire")
        t_node.position = gamer8640.position
        t_node.position.y += 5
        t_node.physicsBody = SKPhysicsBody(circleOfRadius: t_node.size.width / 2)
        t_node.physicsBody?.isDynamic = true
        t_node.physicsBody?.contactTestBitMask = Category
        t_node.physicsBody?.contactTestBitMask = clashStyle
        t_node.physicsBody?.collisionBitMask = 0
        t_node.physicsBody?.usesPreciseCollisionDetection = true
        self.addChild(t_node)
        
        let animation_time:TimeInterval = 0.2
        var task = [SKAction]()
        
        task.append(SKAction.move(to: CGPoint(x: gamer8640.position.x, y: self.frame.size.height), duration: animation_time))
        task.append(SKAction.removeFromParent())
        
        t_node.run(SKAction.sequence(task))
        
        
    }
    
    
    
    
    override func didMove(to view: SKView) {
        
        // Get label node from scene and store it for use later
        self.label = self.childNode(withName: "//helloLabel") as? SKLabelNode
        if let label = self.label {
            label.alpha = 0.0
            label.run(SKAction.fadeIn(withDuration: 2.0))
            
            field8640 = SKEmitterNode(fileNamed: "field8640")
            field8640.position = CGPoint(x: 0, y: 1345)
            field8640.advanceSimulationTime(15)
            self.addChild(field8640)
            field8640.zPosition = -1
            
            gamer8640 = SKSpriteNode(imageNamed: "spaceship")
            gamer8640.position = CGPoint(x: -100, y: -440)
            self.addChild(gamer8640)
            self.physicsWorld.gravity = CGVector(dx: 0, dy: 0)
            self.physicsWorld.contactDelegate = self
            
            scoreLabel = SKLabelNode(text: "Score: 0")
            scoreLabel.position = CGPoint(x: 200, y: 470)
            scoreLabel.fontSize = 30
            score = 0
            
            self.addChild(scoreLabel)
            
            Time8640 = Timer.scheduledTimer(timeInterval: 0.75, target: self, selector: #selector(Intersticial_animal), userInfo: nil, repeats: true)
            
            movement.accelerometerUpdateInterval = 0.2
            movement.startAccelerometerUpdates(to: OperationQueue.current!)
            {
                (data:CMAccelerometerData?, error:Error?) in
                if let accelerometerData = data{
                    let acceleration = accelerometerData.acceleration
                    self.xSpeed = CGFloat(acceleration.x) * 0.75 + self.xSpeed * 0.25
                }
            }
            
            
        }
        
        // Create shape node to use during mouse interaction
        let w = (self.size.width + self.size.height) * 0.05
        self.spinnyNode = SKShapeNode.init(rectOf: CGSize.init(width: w, height: w), cornerRadius: w * 0.3)
        
        if let spinnyNode = self.spinnyNode {
            spinnyNode.lineWidth = 2.5
            
            spinnyNode.run(SKAction.repeatForever(SKAction.rotate(byAngle: CGFloat(Double.pi), duration: 1)))
            spinnyNode.run(SKAction.sequence([SKAction.wait(forDuration: 0.5),
                                              SKAction.fadeOut(withDuration: 0.5),
                                              SKAction.removeFromParent()]))
        }
    }

    
    func touchDown(atPoint pos : CGPoint) {
        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.green
            self.addChild(n)
        }
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.blue
            self.addChild(n)
        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        if let n = self.spinnyNode?.copy() as! SKShapeNode? {
            n.position = pos
            n.strokeColor = SKColor.red
            self.addChild(n)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let label = self.label {
            label.run(SKAction.init(named: "Pulse")!, withKey: "fadeInOut")
        }
        
        for t in touches { self.touchDown(atPoint: t.location(in: self)) }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchMoved(toPoint: t.location(in: self)) }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
        target_animal()
    }
    
    
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches { self.touchUp(atPoint: t.location(in: self)) }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        var element_1:SKPhysicsBody
        var element_2:SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask
        {
            element_1 = contact.bodyA
            element_2 = contact.bodyB
            
        }else{
            element_1 = contact.bodyB
            element_2 = contact.bodyA
        }
        if (element_1.categoryBitMask & Category) != 0 && (element_2.categoryBitMask & clashStyle) != 0
        {
            spaceship_collision(t_node: element_1.node as! SKSpriteNode, anime_node: element_2.node as! SKSpriteNode)
        }
        
    }
    
    func spaceship_collision(t_node:SKSpriteNode, anime_node:SKSpriteNode)
    {
        let collision = SKEmitterNode(fileNamed: "collision")!
        collision.position = anime_node.position
        self.addChild(collision)
        
        self.run(SKAction.playSoundFileNamed("collision.mp3", waitForCompletion: false))
        t_node.removeFromParent()
        anime_node.removeFromParent()
        
        self.run(SKAction.wait(forDuration: 3)){
            collision.removeFromParent()}
        
        score += 5
        
        
        
    }
    
    override func didSimulatePhysics() {
        gamer8640.position.x += xSpeed * 50
        if gamer8640.position.x < -20 {
            gamer8640.position = CGPoint(x: self.size.width + 20, y: gamer8640.position.y)
        }
        else if gamer8640.position.x > self.size.width + 20 {
                gamer8640.position = CGPoint(x: -20, y: gamer8640.position.y)
            }
        }
    }
    
func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }

